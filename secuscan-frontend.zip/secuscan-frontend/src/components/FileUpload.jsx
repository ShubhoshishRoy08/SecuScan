import { useState } from "react";
import { uploadFile } from "../api";

export default function FileUpload({ setVulnerabilities }) {
  const [file, setFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  const handleUpload = async () => {
    if (!file) {
      setMessage("Please select a file first!");
      return;
    }

    setLoading(true);
    const response = await uploadFile(file);
    setLoading(false);

    if (response.vulnerabilities) {
      setVulnerabilities(response.vulnerabilities);
    }

    setMessage(response.message);
  };

  return (
    <div className="bg-white shadow-md p-4 rounded-lg">
      <h2 className="text-xl font-bold mb-2">Upload Solidity File</h2>
      <input 
        type="file" 
        accept=".sol" 
        onChange={(e) => setFile(e.target.files[0])} 
        className="border p-2 w-full"
      />
      <button 
        onClick={handleUpload} 
        className="mt-3 bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-600"
      >
        {loading ? "Uploading..." : "Upload"}
      </button>
      {message && <p className="mt-2 text-green-600">{message}</p>}
    </div>
  );
}
