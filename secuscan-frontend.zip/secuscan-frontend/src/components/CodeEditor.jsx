import { useState } from "react";

export default function CodeEditor({ setCode }) {
  const [solidityCode, setSolidityCode] = useState("");

  const handleChange = (event) => {
    setSolidityCode(event.target.value);
    setCode(event.target.value);
  };

  return (
    <div className="bg-white shadow-md p-4 rounded-lg">
      <h2 className="text-xl font-bold mb-2">Write Solidity Code</h2>
      <textarea
        className="border p-2 w-full h-40"
        placeholder="Write your Solidity contract here..."
        value={solidityCode}
        onChange={handleChange}
      />
    </div>
  );
}
