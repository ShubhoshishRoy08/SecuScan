import { useState } from "react";
import FileUpload from "../components/FileUpload";
import CodeEditor from "../components/CodeEditor";
import VulnerabilityReport from "../components/VulnerabilityReport";
import { fetchVulnerabilities } from "../api";

export default function Home() {
  const [vulnerabilities, setVulnerabilities] = useState([]);
  const [code, setCode] = useState("");

  const loadVulnerabilities = async () => {
    const response = await fetchVulnerabilities();
    setVulnerabilities(response.vulnerabilities);
  };

  return (
    <div className="container mx-auto p-6">
      <h1 className="text-3xl font-bold text-center text-blue-700 mb-6">SecuScan - Solidity Security Analyzer</h1>
      <div className="grid md:grid-cols-2 gap-6">
        <FileUpload setVulnerabilities={setVulnerabilities} />
        <CodeEditor setCode={setCode} />
      </div>
      <button
        onClick={loadVulnerabilities}
        className="mt-4 bg-green-500 text-white py-2 px-4 rounded hover:bg-green-600"
      >
        Fetch Vulnerabilities
      </button>
      <VulnerabilityReport vulnerabilities={vulnerabilities} />
    </div>
  );
}
